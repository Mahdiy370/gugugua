# SAMMAKIM — Portfolio website

Shaxsiy portfolio sayt (HTML + CSS + JavaScript).

## Fayllar
- `index.html` — tuzilma (6 bo'lim)
- `style.css` — dizayn, responsiv, qorong'i rejim
- `script.js` — menyu, mavzu almashtirish, chiziqlar animatsiyasi
- `images/me.jpg` — o'z rasmingiz (ixtiyoriy; bo'lmasa "S" harfi ko'rinadi)

## Joylash
1. GitHub'da `portfolio` nomli public repository oching va fayllarni yuklang.
2. vercel.com → Continue with GitHub → Add New → Project → portfolio → Deploy.
